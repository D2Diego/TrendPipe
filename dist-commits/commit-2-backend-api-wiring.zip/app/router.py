"""Application configuration - root APIRouter.

Defines the FastAPI application endpoints for the trend-research feature.

Resources:
    1. https://fastapi.tiangolo.com/tutorial/bigger-applications

"""

from fastapi import APIRouter

from app.controllers.v1 import config as config_v1, providers, research

root_api_router = APIRouter()
# v1
root_api_router.include_router(research.router)
root_api_router.include_router(providers.router)
root_api_router.include_router(config_v1.router)
