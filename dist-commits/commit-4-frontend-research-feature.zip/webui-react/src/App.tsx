import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { I18nextProvider } from "react-i18next";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import i18n from "@/i18n";
import { ResearchListPage } from "@/features/researches/ResearchListPage";
import { ResearchDetailPage } from "@/features/researches/ResearchDetailPage";
import { StartPage } from "@/features/start/StartPage";

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });

export function AppRoutes() {
  return <>
    <Routes>
      <Route path="/" element={<StartPage />} />
      <Route path="/researches" element={<ResearchListPage />} />
      <Route path="/researches/settings" element={<Navigate to="/researches?settings=researcher" replace />} />
      <Route path="/researches/:id" element={<ResearchDetailPage />} />
    </Routes>
  </>;
}

export default function App() {
  return <QueryClientProvider client={queryClient}><I18nextProvider i18n={i18n}>
    <main className="min-h-screen bg-background text-foreground">
      <BrowserRouter><AppRoutes /></BrowserRouter>
    </main>
  </I18nextProvider></QueryClientProvider>;
}
